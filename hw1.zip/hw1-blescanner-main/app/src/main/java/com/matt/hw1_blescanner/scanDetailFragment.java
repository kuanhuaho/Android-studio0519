package com.matt.hw1_blescanner;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import org.jetbrains.annotations.NotNull;

public class scanDetailFragment extends Fragment {

    private View view;
    private androidx.appcompat.widget.Toolbar tb_back;
    private TextView tv_detail_mac;
    private TextView tv_detail_rssi;
    private TextView tv_detail_content;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_scan_detail, container, false);

        tb_back = view.findViewById(R.id.tb_back);
        tv_detail_mac = view.findViewById(R.id.tv_detail_mac);
        tv_detail_rssi = view.findViewById(R.id.tv_detail_rssi);
        tv_detail_content = view.findViewById(R.id.tv_detail_content);

        tb_back.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("onClick: ", "BackPressed");
                NavController navController = Navigation.findNavController(view);
                // Navigating to Previous Fragment
                navController.popBackStack();
            }
        });
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        // Safe Arguments Received
        scanDetailFragmentArgs args = scanDetailFragmentArgs.fromBundle(getArguments());
        tv_detail_mac.setText(args.getMacAddress());
        tv_detail_rssi.setText(args.getRssi());
        tv_detail_content.setText(args.getContent());
    }
}