package com.matt.hw1_blescanner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ScannerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanpage);
    }

    @Override
    public void onBackPressed() {
        // do nothing to disable back pressed
    }
}